# data/__init__.py
# Этот файл делает папку data пакетом Python 