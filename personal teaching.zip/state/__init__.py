# state/__init__.py
# Этот файл делает папку state пакетом Python 