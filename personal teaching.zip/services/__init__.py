# services/__init__.py
# Этот файл делает папку services пакетом Python 