# handlers/__init__.py
# Этот файл делает папку handlers пакетом Python 
# Пользовательские обработчики перенесены в handlers/users/ 