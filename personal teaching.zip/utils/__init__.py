# utils/__init__.py
# Этот файл делает папку utils пакетом Python 