#!/usr/bin/env python3
"""
Тест уведомлений о новых заявках
"""

import sqlite3
import os
from datetime import datetime

def test_notification_system():
    """Тестирует систему уведомлений"""
    print("🔔 ТЕСТИРОВАНИЕ СИСТЕМЫ УВЕДОМЛЕНИЙ")
    print("=" * 50)
    
    # Проверяем базу данных
    db_path = "data/database.db"
    if not os.path.exists(db_path):
        print(f"❌ База данных не найдена: {db_path}")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Проверяем структуру таблицы applications
        cursor.execute("PRAGMA table_info(applications)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        
        print("📊 Структура таблицы applications:")
        for col in columns:
            print(f"   {col[1]} ({col[2]})")
        
        # Проверяем количество заявок
        cursor.execute("SELECT COUNT(*) FROM applications")
        total_apps = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM applications WHERE status = 'Ожидает'")
        pending_apps = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM applications WHERE status = 'Назначено'")
        assigned_apps = cursor.fetchone()[0]
        
        print(f"\n📈 Статистика заявок:")
        print(f"   Всего заявок: {total_apps}")
        print(f"   Ожидающих: {pending_apps}")
        print(f"   Назначенных: {assigned_apps}")
        
        # Проверяем последние заявки
        cursor.execute("""
            SELECT id, tg_id, parent_name, student_name, course, status, created_at 
            FROM applications 
            ORDER BY created_at DESC 
            LIMIT 5
        """)
        recent_apps = cursor.fetchall()
        
        if recent_apps:
            print(f"\n📋 Последние заявки:")
            for app in recent_apps:
                app_id, tg_id, parent_name, student_name, course, status, created_at = app
                print(f"   #{app_id}: {parent_name} - {student_name} ({course}) - {status}")
        
        # Проверяем архив
        cursor.execute("SELECT COUNT(*) FROM archive")
        archived_count = cursor.fetchone()[0]
        print(f"\n📁 Архивных записей: {archived_count}")
        
        conn.close()
        
        print("\n✅ Система уведомлений готова к работе")
        print("\n📝 Инструкция по тестированию:")
        print("1. Запустите бота: python bot.py")
        print("2. Отправьте боту команду /start")
        print("3. Нажмите '📋 Записаться'")
        print("4. Заполните форму регистрации")
        print("5. Подтвердите заявку")
        print("6. Проверьте, что админ получил уведомление")
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка при тестировании: {e}")
        return False

def check_config():
    """Проверяет конфигурацию"""
    print("\n🔧 ПРОВЕРКА КОНФИГУРАЦИИ")
    print("=" * 30)
    
    try:
        from config import ADMIN_ID, API_TOKEN
        
        print(f"✅ ADMIN_ID: {ADMIN_ID}")
        print(f"✅ API_TOKEN: {'*' * 10}...{API_TOKEN[-4:] if API_TOKEN else 'None'}")
        
        if not ADMIN_ID:
            print("❌ ADMIN_ID не установлен!")
            return False
        
        if not API_TOKEN:
            print("❌ API_TOKEN не установлен!")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка конфигурации: {e}")
        return False

def main():
    """Главная функция"""
    print("🧪 ТЕСТ СИСТЕМЫ УВЕДОМЛЕНИЙ")
    print("=" * 50)
    
    # Проверяем конфигурацию
    if not check_config():
        print("❌ Проблемы с конфигурацией")
        return 1
    
    # Тестируем систему уведомлений
    if not test_notification_system():
        print("❌ Проблемы с системой уведомлений")
        return 1
    
    print("\n🎉 Все проверки пройдены!")
    print("✅ Система уведомлений работает корректно")
    return 0

if __name__ == "__main__":
    import sys
    sys.exit(main()) 