import os

API_TOKEN = "7906419182:AAFkvUNgQpbgAka959-gC1oL0WGvq58SPJs"
ADMIN_ID = "853510094"  # Замените на ваш Telegram ID

